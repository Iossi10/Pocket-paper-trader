# Pocket Paper Trader — phone-friendly web app

This is a self-contained, mobile-responsive paper-trading demo with a $100 simulated balance, moving-average crossover signals, simulated stop-loss, P/L tracking, and daily/trade summaries.

**Important:** The app uses generated illustrative prices, not real stock quotes or historical market data. It has no broker integration and cannot place real orders.

## Try it
1. Download and unzip the project.
2. Open `index.html` in a browser.
3. Tap **Run next day** to step through demo candles. Changing settings resets the simulation.

## Publish for phone access using GitHub Pages
1. Sign in at https://github.com/ and create a repository.
2. Upload `index.html` to the repository root.
3. Open repository Settings → Pages.
4. Select deployment from the `main` branch and `/ (root)`, then save.
5. Open the published website URL on your phone.

This is a static demo with no API keys, backend, or live feed.
